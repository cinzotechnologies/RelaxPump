RelaxPump Relay Board Rev B - KiCad schematic for EasyEDA Pro import

230 V in -> F1 -> MOV -> PS1 AC-DC 12 V 5 A -> +12V -> buck 5 V -> AMS1117 3.3 V
K1 relay: COM = 230 V L (after F1), NO -> J2 PUMP OUT (to the contactor coil)
K2-K6 relays: COM = +12V, NO -> J4-J8 valve terminals (SS34 flyback on each)
ULN2003A drives the relay coils from the ESP32 (relay ON = GPIO HIGH)
6 sensor connectors J9-J14 (1 5V, 2 GND, 3 ECHO, 4 TRIG), echo dividers 1k/2k
ESP32-WROOM-32E (Wi-Fi + BLE), RESET, BOOT, Wi-Fi LED (IO2), power LED, UART header J3
Mounting holes H1-H4 are not in the schematic: add them on the PCB.

Pad numbering: diodes/LEDs 1 = cathode, 2 = anode; electrolytic 1 = +; U1 WROOM pins 1-38 + 39 GND pad;
ULN2003A 1-7 IN, 8 GND, 9 COM, 10-16 OUT; AMS1117 1 GND, 2 VOUT, 3 VIN, 4 tab;
relays 1 COIL+, 2 COIL-, 3 COM, 4 NO, 5 NC - CHECK this against the relay footprint you pick in EasyEDA.
PS1 1 AC/L, 2 AC/N, 3 -V, 4 +V - CHECK against the IRM-60-12 footprint.
